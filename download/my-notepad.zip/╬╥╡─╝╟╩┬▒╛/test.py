import tkinter as tk
from tkinter import filedialog

root = tk.Tk()
root.withdraw()  # 隐藏主窗口

filename = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])

if filename:
    print("选择的文件名:", filename)
else:
    print("未选择文件名或取消操作")
while(True):
    ans=1